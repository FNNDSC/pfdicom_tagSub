try:
    from .pfdicom_tagExtract    import pfdicom_tagExtract
except:
    from pfdicom_tagExtract     import pfdicom_tagExtract
