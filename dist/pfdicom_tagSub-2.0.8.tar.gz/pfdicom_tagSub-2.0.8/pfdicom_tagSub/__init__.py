try:
    from .pfdicom_tagSub    import pfdicom_tagSub
except:
    from pfdicom_tagSub     import pfdicom_tagSub
